#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>

int main(int argc, char* argv[]){
    
    //main shell process, i have selected rm for man and -r for grep
    printf("I’m SHELL process, with PID: %d - Main command is: man rm | grep \\\\-d -A 1 -m 1 > output.txt\n", getpid());
   
     
     //creating a pipe process
     //fd as in file descriptors
     int fd1[2]; int fd2[2];//an array of 2 -> to read and write
     pipe(fd1); pipe(fd2);
    
    // forking the first command MAN or rm
    int f1 = fork();

    //checking if there is a problem
    if(f1<0){ // if it failed, we should exit
        fprintf(stderr, "fork failed\n");
        exit(1);
    }
    // child process MAN created succesfully

    else if(f1 == 0){
        printf("I’m MAN process, with PID: %d - My command is: man rm\n", getpid());
        int f2 = fork(); //GREP
        
        //GREP failed
        if(f2 <0){
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        //GREP
        else if(f2 == 0){
            // printing the GREP process message
            printf("I’m GREP process, with PID: %d - My command is: grep \\\\-d -A 1 -m 1\n", getpid());
            close(fd2[0]);
            close(fd1[1]);
            dup2(fd1[0],STDIN_FILENO);
            //close(fd1[0]);
            dup2(fd2[1],STDOUT_FILENO);
            
           

            execlp("grep", "grep", "\\-d", "-A", "1", "-m", "1",NULL);
        }
        //MAN
        else{
            
            // printing the MAN process message
            close(fd1[0]);
            close(fd2[1]);
            close(fd2[0]);
            dup2(fd1[1],STDOUT_FILENO);
            //executing the man with rm command
            execlp("man", "man", "rm", NULL);
        }
     

    }
    //SHELL
    else{
        

        close(fd1[0]); close(fd1[1]);
        
        int outputFile = open("output.txt",O_WRONLY|O_CREAT,S_IRWXU|S_IRWXG|S_IRWXO);
        close(fd2[1]);
        
        dup2(fd2[0],STDIN_FILENO);

        waitpid(f1,NULL,0);
        wait(NULL);

        printf("I’m SHELL process, with PID:%d - execution is completed, you can find the results in output.txt\n", getpid());

        dup2(outputFile,STDOUT_FILENO);
            
         
        execlp("cat", "cat", NULL);
        
    }
    return 0;
}
